from flask import Flask
app = Flask(__name__)
app.secret_key = 'keepitsecret'

print('---------')
print('Success is the sum of small efforts,\nrepeated day in and day out.')
print('---------')